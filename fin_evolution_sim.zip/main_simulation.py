import numpy as np
from hydrodynamics import simulate_roll
from fitness_landscape import fitness

N = 100
generations = 100
mutation_sigma = 0.05
gamma = np.random.uniform(-1, 1, N)
kf = np.random.uniform(0.05, 2.0, N)

for gen in range(generations):
    F = np.array([fitness(g, k, noise=True) for g, k in zip(gamma, kf)])
    elite_idx = np.argsort(F)[-20:]
    parents = np.random.choice(elite_idx, size=N, replace=True)
    gamma = gamma[parents] + np.random.normal(0, mutation_sigma, N)
    kf = kf[parents] + np.random.normal(0, mutation_sigma, N)
    gamma = np.clip(gamma, -1, 1)
    kf = np.clip(kf, 0.05, 2.0)

np.savez("data/final_population.npz", gamma=gamma, kf=kf)
print("Simulation complete. Results saved to data/final_population.npz")
