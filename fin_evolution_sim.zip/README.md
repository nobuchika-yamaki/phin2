# Evolutionary Simulation of Contralateral Fin-Control Architectures

This repository contains the full simulation and analysis code accompanying the paper:

> [Title of your paper].  
> [Author Names].  
> Submitted to *Nature Communications* (2025).

## Overview
This repository implements the two-stage quantitative framework described in the manuscript:
1. **Hydrodynamic roll-stability model (Stage 1)**
2. **Evolutionary simulation of fin-control architectures (Stage 1.5)**
3. **Developmental geometry analysis (Stage 2)**

All code is written in Python 3.12 and uses `NumPy`, `SciPy`, and `Matplotlib`.

## Installation

```bash
conda env create -f environment.yml
conda activate fin_evo
```

## Running the simulation

```bash
python main_simulation.py
```

Output data and figures will be saved under `data/example_output/`.

## Citation
If you use this code, please cite:

> [Your Name] et al. (2025). *Contralateral control as a physically optimal and evolutionarily inevitable architecture in vertebrate motor systems.*  
> Zenodo DOI: [to be generated].

## License
MIT License
