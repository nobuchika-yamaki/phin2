from hydrodynamics import simulate_roll

def fitness(gamma, kf, noise=False):
    J_stab, J_eff = simulate_roll(gamma, kf)
    J = J_stab + 0.1 * J_eff
    return 1.0 / J
