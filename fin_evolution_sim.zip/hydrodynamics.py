import numpy as np

def simulate_roll(gamma, kf, A=0.5, mu=0.1, sigma=0.02, T=5.0, dt=0.001):
    c = 0.5
    k = 0.2
    theta, omega = 0.0, 0.0
    t = np.arange(0, T, dt)

    tau_wave = A * np.exp(-((t - mu)**2) / (2 * sigma**2))
    tau_fin = np.zeros_like(t)

    for i in range(1, len(t)):
        phi_L = -kf * theta
        phi_R = -gamma * kf * theta
        tau_fin[i] = 0.2 * (phi_L - phi_R)
        omega += dt * (tau_fin[i] - tau_wave[i] - c * omega - k * theta)
        theta += dt * omega

    effort = np.trapz(phi_L**2 + phi_R**2, t)
    return abs(theta), effort
