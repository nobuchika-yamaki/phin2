def ipsilateral(theta, kf):
    phi_L, phi_R = 0, -kf * theta
    return 0.2 * (phi_L - phi_R)

def contralateral(theta, kf):
    phi_L, phi_R = -kf * theta, 0
    return 0.2 * (phi_L - phi_R)

def bilateral(theta, kf, gamma):
    phi_L = -kf * theta
    phi_R = -gamma * kf * theta
    return 0.2 * (phi_L - phi_R)
