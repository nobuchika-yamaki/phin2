import matplotlib.pyplot as plt
import numpy as np
from roll_model import simulate_roll
from control_architectures import bilateral

t = np.arange(0, 5.0, 0.001)
tau_wave = 0.5 * np.exp(-((t - 0.1)**2)/(2*0.02**2))

def plot_contralateral_response():
    def control(theta): return bilateral(theta, kf=2.0, gamma=-1)
    theta_hist, _ = simulate_roll(t, 0, 0, tau_wave, control)
    plt.plot(t, theta_hist)
    plt.xlabel("Time (s)")
    plt.ylabel("Roll angle θ")
    plt.title("Contralateral control response")
    plt.savefig("figures/roll_response.png", dpi=300)
    plt.show()

if __name__ == "__main__":
    plot_contralateral_response()
