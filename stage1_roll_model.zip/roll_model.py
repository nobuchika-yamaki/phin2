import numpy as np

def simulate_roll(t, theta0, omega0, tau_wave, control_func, c=0.5, k=0.2, dt=0.001):
    theta, omega = theta0, omega0
    theta_hist, omega_hist = [theta], [omega]

    for tau_w in tau_wave:
        tau_fin = control_func(theta)
        omega += dt * (tau_fin - tau_w - c * omega - k * theta)
        theta += dt * omega
        theta_hist.append(theta)
        omega_hist.append(omega)

    return np.array(theta_hist), np.array(omega_hist)
