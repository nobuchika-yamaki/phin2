from optimize_gain import optimize_gain
from control_architectures import bilateral
import numpy as np

params = {'I': [1, 1.5, 3.0], 'k': [0.2, 0.3, 0.6], 'CLalpha': [2.0, 3.0, 4.0]}
results = []

for kf_var in params['k']:
    best_kf, best_J = optimize_gain(bilateral, gamma=-1)
    results.append((kf_var, best_kf, best_J))

print("Sensitivity results:", results)
