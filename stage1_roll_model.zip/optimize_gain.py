import numpy as np
from roll_model import simulate_roll
from control_architectures import ipsilateral, contralateral, bilateral

def cost_function(theta_hist, phi_L, phi_R):
    theta_final = abs(theta_hist[-1])
    effort = np.trapz(phi_L**2 + phi_R**2)
    return theta_final + 0.1 * effort

def optimize_gain(arch_func, gamma=0, kf_range=np.arange(0.05, 2.0, 0.05)):
    t = np.arange(0, 5.0, 0.001)
    tau_wave = 0.5 * np.exp(-((t - 0.1)**2) / (2 * 0.02**2))
    best_J, best_kf = 1e9, None

    for kf in kf_range:
        def control(theta): return arch_func(theta, kf) if arch_func.__name__ != 'bilateral' else arch_func(theta, kf, gamma)
        theta_hist, _ = simulate_roll(t, 0, 0, tau_wave, control)
        phi_L, phi_R = -kf * theta_hist, -gamma * kf * theta_hist
        J = cost_function(theta_hist, phi_L, phi_R)
        if J < best_J:
            best_J, best_kf = J, kf
    print(f"Best kf={best_kf:.2f}, J={best_J:.4e}")
    return best_kf, best_J
