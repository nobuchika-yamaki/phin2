# Stage 1: Hydrodynamic Roll-Stability Model

This repository implements the physical modeling component (Stage 1) of the study:
> Contralateral control as a physically optimal and evolutionarily inevitable architecture in vertebrate motor systems.

## Overview
This model evaluates the roll-stabilization performance of alternative fin-control architectures using a simplified hydrodynamic framework.

### Key Components
- `roll_model.py`: numerical integration of roll dynamics.
- `control_architectures.py`: ipsilateral, contralateral, and bilateral control functions.
- `optimize_gain.py`: optimizes feedback gain kf to minimize total cost J.
- `sensitivity_analysis.py`: evaluates robustness to ±50% and ±200% parameter variation.
- `plotting.py`: generates figures for roll response and comparative performance.

## Usage

```bash
conda env create -f environment.yml
conda activate fin_roll
python optimize_gain.py
python plotting.py
```

Results are saved under `results/` and `figures/`.

## License
MIT License
